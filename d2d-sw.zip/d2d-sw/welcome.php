<html>
<head>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<script src="jquery-1.11.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js">
</script>
<style>
body {
    background: url('pics/d2d3.jpg') no-repeat fixed center center;
    background-size: cover;
    font-family: Montserrat;
}
h1{
	color:#e65c00;
}
#d2d{
	font-size:1em;
}
</style>
</head>
<body>
<center><h1>Welcome to DOOR To DOOR Services</h1><br/>
<br/><br/><br/><br/>

	<div class="btn-group">
		<a href="cust-details.php" type="button" id="d2d" class="btn btn-danger btn-large" type="submit">Customer Details</a>
		
	</div>
	&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;
	<div class="btn-group">
		<a href="rate-list.php" type="button" id="d2d" class="btn btn-info btn-large" type="submit">Rate List</a>
		
	</div>
	&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;
	<div class="btn-group" align="right">
		
		<a href="software.php" role="button" id="d2d" class="btn btn-primary btn-large" type="submit">Invoice Billing</a>
		
	</div>
	</center>
</body>

</html>