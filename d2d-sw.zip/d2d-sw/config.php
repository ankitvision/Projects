<?php
$con=mysqli_connect("localhost","root","","d2d-sw");
if(mysqli_connect_error())
{
echo "failed to connect with MySqli:".mysqli_connect_error();
}
?>