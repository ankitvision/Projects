	<?php 
	include 'config.php';
		if(isset($_POST['q'])){
			$q=strval($_POST['q']);
			//print_r($q); die(mm);
				$query=mysqli_query($con,"SELECT DISTICT category FROM data_list WHERE type LIKE '%{$q}%'");
?>		
		<select>
			<?php
			foreach($query as $row){
			  echo "<option value=$row[category]>$row[category]</option>";
			}
			
		}
	?>
	</select>