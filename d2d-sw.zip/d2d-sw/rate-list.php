<html>
 <title>Service Rate List</title>
 <head>
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<script src="jquery-1.11.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js">
</script>
 </head>
 <body>
   <div class="jumbotron">
   <center>
  <h1>Service Charges Card</h1>
    <p><select name="service" class="pull-left" id="serv" style="margin-left:80px; text-align:center;">
	   <option value="">Select one</option>
	   <?php 
		  require 'config.php';
		  $q=mysqli_query($con,"SELECT DISTINCT type FROM data_list");
		  foreach($q as $row){
			  echo "<option value=$row[type]>$row[type]</option>";
		  }
	   ?>
	</select>
	<select name="category" id="cat" class="pull-right" style="margin-right:80px;">
	<option value=''>Select Category</option>

	</select>
	</p>
</div>
 </body>
</html>
<script src="jquery-1.11.3.min.js"></script>
<script>
	$("#serv").on('change',function(e){
	var cn = $(this).val();
	//alert(cn); die(mm);
		$.ajax({
			
        type : "POST",
        url : "get-type.php",
        data: {q:cn},
        success : function(data) { 
		//alert(data); die(mm);
		  $('#cat').html(data); 
		}
	});
});
</script>
<?php

?>