<?php
session_start();
?>
<html>
	<head>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<script src="jquery-1.11.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js">
</script>
		<style>
			h3{
				color:red;
			}
			label{
				font-size:1.25em;
			
				font-decoration:strong;
			}
			th{
				text-align:center;
			}
			#sn{
				width:80px;
			}
			
			/* #d{
				margin-top:20px;
				float:left;
			}  */
		</style>
		
	</head>
	<body>
		<center>
			<h3><b> DOOR To DOOR <i>Laundary Services</i> </b></h3>
			<h4><b>Princess Park near Sai Mandir</b></h4>
			<h4><b>Greater Faridabad, Haryana</b></h4>
		</center><br/><br/>
	<div class="col-lg-12">
		  <form action="" autocomplete="on" method="post" class="form-horizontal">
		  
		   <div class="form-group">
		   <label for="name" class="col-lg-2 control-label">Name:</label>
		   <div class="col-lg-4">
		   <input type="text" class="form-control" name="name" id="name" size="10px" placeholder="Enter Customer Name">
		   </div>
		   </div>
		   
		   <div class="form-group">
		   <label for="address" class="col-lg-2 control-label">Address:</label>
		   <div class="col-lg-4">
		   <textarea id="address" placeholder="Enter Customer Address" name="add" rows="7" cols="36"></textarea>
		   </div>
		   </div>
		   
		   <div class="form-group">
		   <label for="contact" class="span2 control-label">Contact No.:</label>
		   <div class="col-lg-4">
		   <input type="text" class="form-control span2" id="contact" name="num" size="10px" placeholder="Enter Customer Number">
		   </div>
		   </div>
		   <?php
		     date_default_timezone_set("Asia/Kolkata");
	       ?>
		   <div class="col-md-6 pull-left" id="d">
		   <div class="form-group" id="dt">
		   <label for="dt" class="col-lg-2 control-label">Date:</label>
		   <div class="col-lg-4">
		   <input type="date" class="form-control" value="<?php echo date('d-m-Y');?>" name="dt" id="dt" size="10px">
		   </div>
		   </div>
		   
		    <div class="form-group" id="dod">
		   <label for="dod" class="col-lg-2 control-label">Delivery Date:</label>
		   <div class="col-lg-4">
		   <input type="date" class="form-control" name="dod" id="dod" size="10px">
		   </div>
		   </div>
		   </div>
		   
		   
		 </div>
	   </div>
	  <table width="95%" border="1px solid">
		<th id="sn">S.No.</th>
		<th>Items</th>
		<th>Service</th>
		<th style="width:200px;">Category</th>
		<th>Price</th>
		<th style="width:80px;">Quantity</th>
		<th>Total</th>
	  </table>
	</form>
	</body>
</html>