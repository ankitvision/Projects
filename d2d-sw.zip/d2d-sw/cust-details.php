<?php
include 'config.php';
?>
<html>
<head>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<script src="jquery-1.11.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js">
</script>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 15px;
}
.inner-addon { 
    position: relative; 
}

/* style icon */
.inner-addon .glyphicon {
  position: absolute;
  padding: 10px;
  pointer-events: none;
}

/* align icon */
.left-addon .glyphicon  { left:  0px;}
.right-addon .glyphicon { right: 0px;}

/* add padding  */
.left-addon input  { padding-left:  30px; }
.right-addon input { padding-right: 30px; }
</style>
</head>
<body>
<a href="software.php" type="button" class="btn btn-primary btn-large" type="submit">Billing Software</a>
<center>
<br/>
<br/>
<br/>
<br/>

<form method="post" name="cust-search" action="cust-details.php">
<div id="searchbox" class="inner-addon right-addon">

<input type="text" placeholder="Name" id="searchname" name="searchname"/>
<input type="text" placeholder="Contact Number" id="searchmob" class="searchmob"/>
<input type="submit" name="search" id="searchblock" '<i class="glyphicon glyphicon-search"></i><b>Search</b>' class="searchbtn"/>
</div>
</form>

<table style="width:100%">
<tr>
	<th></th>
  <th>S_No.</th>
 <th>NAME</th>
 <th>ADDRESS</th>
 <th>CONTACT No.</th>
 <th>ITEMS</th>
 <th>DELIVERY DATE</th>
 <th>TOTAL BILL</th>
 <th>REMARKS</th>
 <th></th>
 <th></th>
</tr>

<?php 

include 'config.php';
$q2="SELECT * FROM cust_details";

$result2=mysqli_query($con,$q2);
//print_r($result2); die("lost");
while($f=mysqli_fetch_array($result2))
	
{
	//print_r($f);
?>
<tr>
	<td><input type="checkbox" name="chk"/></td>
	<td><?php echo $f['id']?></td>
	<td><?php echo $f['name']?></td>
	<td><?php echo $f['address']?></td>
	<td><?php echo $f['contact']?></td>
	<td><?php echo $f['items']?></td>
	<td><?php echo $f['dod']?></td>
	<td><?php echo $f['t-bill']?></td>
	<td><?php echo $f['remarks']?></td>
	<td><a href="edit.php?id=<?php echo $f['id']?>">EDIT</a></td>
	<td><a href="delete.php?id=<?php echo $f['id']?>">DELETE</a></td>
</tr>
<?php
}

?>
</table>


</body>
</html>