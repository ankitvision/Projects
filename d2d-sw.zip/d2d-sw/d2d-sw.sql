-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 08, 2016 at 07:56 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `d2d-sw`
--

-- --------------------------------------------------------

--
-- Table structure for table `cust_details`
--

CREATE TABLE IF NOT EXISTS `cust_details` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` bigint(10) NOT NULL,
  `items` int(11) NOT NULL,
  `dod` date NOT NULL,
  `t-bill` int(11) NOT NULL,
  `remarks` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cust_details`
--

INSERT INTO `cust_details` (`id`, `name`, `address`, `contact`, `items`, `dod`, `t-bill`, `remarks`) VALUES
(1, 'Ankit Pathak', '1062/18 faridabad haryana near gurudwara', 9811836081, 10, '2016-02-10', 500, 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `data_list`
--

CREATE TABLE IF NOT EXISTS `data_list` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `items` varchar(1000) NOT NULL,
  `price` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=228 ;

--
-- Dumping data for table `data_list`
--

INSERT INTO `data_list` (`id`, `type`, `category`, `items`, `price`) VALUES
(1, 'Dry Clean', 'Men', 'Shirt', 50),
(2, 'Dry Clean', 'Men', 'T-Shirt', 50),
(3, 'Dry Clean', 'Men', 'Trouser', 50),
(4, 'Dry Clean', 'Men', 'Lower', 50),
(5, 'Dry Clean', 'Men', 'Kurta', 50),
(6, 'Dry Clean', 'Men', 'Pyjama', 50),
(7, 'Dry Clean', 'Men', 'Kurta-Pyjama', 100),
(8, 'Dry Clean', 'Men', 'Blazer', 130),
(9, 'Dry Clean', 'Men', 'Suit(2pc)', 180),
(10, 'Dry Clean', 'Men', 'Suit(3pc)', 210),
(11, 'Dry Clean', 'Men', 'Waist Coat', 50),
(12, 'Dry Clean', 'Men', 'Safari Suit(2pc)', 100),
(13, 'Dry Clean', 'Men', 'Jacket', 130),
(14, 'Dry Clean', 'Men', 'Leather Jacket', 200),
(15, 'Dry Clean', 'Men', 'Woolen Coat', 150),
(16, 'Dry Clean', 'Men', 'Cardigan Long', 150),
(17, 'Dry Clean', 'Men', 'Sherwani', 200),
(18, 'Dry Clean', 'Men', 'Sweat Shirts', 80),
(19, 'Dry Clean', 'Men', 'Pullover', 80),
(20, 'Dry Clean', 'Men', 'Muflar', 40),
(21, 'Dry Clean', 'Men', 'Shawl', 50),
(22, 'Dry Clean', 'Men', 'Sleeveless Sweater', 60),
(23, 'Dry Clean', 'Men', 'Sweater', 80),
(24, 'Dry Clean', 'Men', 'Tie', 20),
(25, 'Dry Clean', 'Men', 'Shorts', 40),
(26, 'Dry Clean', 'Men', 'Jeans', 50),
(27, 'Dry Clean', 'Men', 'Nehru/Modi Jacket', 50),
(28, 'Steam Press ', 'Men', 'Shirt', 20),
(29, 'Steam Press', 'Men', 'T-shirt', 20),
(30, 'Steam Press ', 'Men', 'Trouser', 20),
(31, 'Steam Press', 'Men', 'Lower', 20),
(32, 'Steam Press', 'Men', 'Kurta', 20),
(33, 'Steam Press', 'Men', 'Pyjama', 20),
(34, 'Steam Press', 'Men', 'Kurta-Pyjama', 40),
(35, 'Steam Press', 'Men', 'Blazer', 40),
(36, 'Steam Press', 'Men', 'Suit(2pc)', 60),
(37, 'Steam Press', 'Men', 'Suit(3pc)', 80),
(38, 'Steam Press', 'Men', 'Waist Coat', 20),
(39, 'Steam Press', 'Men', 'Safari Suit(2pc)', 40),
(40, 'Steam Press', 'Men', 'Jacket', 40),
(41, 'Steam Press', 'Men', 'Woolen Coat', 40),
(42, 'Steam Press', 'Men', 'Cardigan Long', 50),
(43, 'Steam Press', 'Men', 'Sweat Shirts', 20),
(44, 'Steam Press', 'Men', 'Pullover', 20),
(45, 'Steam Press', 'Men', 'Muflar', 20),
(46, 'Steam Press', 'Men', 'Shawl', 20),
(47, 'Steam Press', 'Men', 'Sleeveless Sweater', 20),
(48, 'Steam Press', 'Men', 'Sweater', 20),
(49, 'Steam Press', 'Men', 'Tie', 10),
(50, 'Steam Press', 'Men', 'Shorts', 10),
(51, 'Steam Press', 'Men', 'Jean', 50),
(52, 'Steam Press', 'Men', 'Nehru/Modi Jacket', 30),
(53, 'Dry Clean', 'Women', 'Saree', 80),
(54, 'Dry Clean', 'Women', 'Saree Heavy', 100),
(55, 'Dry Clean', 'Women', 'Blouse', 20),
(56, 'Dry Clean', 'Women', 'Kurta', 50),
(57, 'Dry Clean', 'Women', 'Anarkali Kurta', 70),
(58, 'Dry Clean', 'Women', 'Suit(2pc)', 100),
(59, 'Dry Clean', 'Women', 'Suit(3pc)', 100),
(60, 'Dry Clean', 'Women', 'Dupatta', 30),
(61, 'Dry Clean', 'Women', 'Salwar', 30),
(62, 'Dry Clean', 'Women', 'Woolen Coat', 130),
(63, 'Dry Clean', 'Women', 'Cardigan Long', 150),
(64, 'Dry Clean', 'Women', 'Sleeveless Sweater', 60),
(65, 'Dry Clean', 'Women', 'Sweater', 80),
(66, 'Dry Clean', 'Women', 'Gown', 50),
(67, 'Dry Clean', 'Women', 'Gown(1pc)', 150),
(68, 'Dry Clean', 'Women', 'Short Dress', 100),
(69, 'Dry Clean', 'Women', 'Shorts', 40),
(70, 'Dry Clean', 'Women', 'Party Wear Dress', 150),
(71, 'Dry Clean', 'Women', 'Skirt', 50),
(72, 'Dry Clean', 'Women', 'Shawl', 50),
(73, 'Dry Clean', 'Women', 'Pashmina Shawl', 150),
(74, 'Dry Clean', 'Women', 'Saree Charak', 40),
(75, 'Dry Clean', 'Women', 'Top', 40),
(76, 'Dry Clean', 'Women', 'Jeans', 50),
(77, 'Dry Clean', 'Women', 'Lehenga(1pc)', 150),
(78, 'Dry Clean', 'Women', 'Choli', 30),
(79, 'Dry Clean', 'Women', 'Lehenga(3pc)', 200),
(80, 'Dry Clean', 'Women', 'Odhni', 70),
(81, 'Steam Press', 'Women', 'Saree', 40),
(82, 'Steam Press', 'Women', 'Saree Heavy', 40),
(83, 'Steam Press', 'Women', 'Blouse', 20),
(84, 'Steam Press', 'Women', 'Kurta', 20),
(85, 'Steam Press', 'Women', 'Anarkali Kurta', 30),
(86, 'Steam Press', 'Women', 'Suit(2pc)', 40),
(87, 'Steam Press', 'Women', 'Suit(3pc)', 50),
(88, 'Steam Press', 'Women', 'Dupatta', 20),
(89, 'Steam Press', 'Women', 'Salwar', 20),
(90, 'Steam Press', 'Women', 'Woolen Coat', 40),
(91, 'Steam Press', 'Women', 'cardigan Long', 50),
(92, 'Steam Press', 'Women', 'Sleeveless Sweater', 20),
(93, 'Steam Press', 'Women', 'Sweater', 20),
(94, 'Steam Press', 'Women', 'Gown', 20),
(95, 'Steam Press', 'Women', 'Gown(1pc)', 50),
(96, 'Steam Press', 'Women', 'Short Dress', 50),
(97, 'Steam Press', 'Women', 'Shorts', 10),
(98, 'Steam Press', 'Women', 'Party Wear Dress', 50),
(99, 'Steam Press', 'Women', 'Skirt', 20),
(100, 'Steam Press', 'Women', 'Shawl', 20),
(101, 'Steam Press', 'Women', 'Pashmina Shawl', 50),
(102, 'Steam Press', 'Women', 'Top', 20),
(103, 'Steam Press', 'Women', 'Jeans', 50),
(104, 'Steam Press', 'Women', 'Lehenga(1pc)', 20),
(105, 'Steam Press', 'Women', 'Choli', 20),
(106, 'Steam Press', 'Women', 'Lehenga(3pc)', 100),
(107, 'Steam Press', 'Women', 'Odhni', 40),
(108, 'Dry Clean', 'Boy', 'T-Shirt', 40),
(109, 'Dry Clean', 'Boy', 'Shirt', 40),
(110, 'Dry Clean', 'Boy', 'Lower', 40),
(111, 'Dry Clean', 'Boy', 'Trouser', 40),
(112, 'Dry Clean', 'Boy', 'School Blazer', 70),
(113, 'Dry Clean', 'Boy', 'Blazer', 70),
(114, 'Dry Clean', 'Boy', 'Suit(2pc)', 110),
(115, 'Dry Clean', 'Boy', 'Suit(3pc)', 130),
(116, 'Dry Clean', 'Boy', 'Jacket', 80),
(117, 'Dry Clean', 'Boy', 'LT. Jacket', 119),
(118, 'Dry Clean', 'Boy', 'Sweat Shirts', 40),
(119, 'Dry Clean', 'Boy', 'Pullover', 40),
(120, 'Dry Clean', 'Boy', 'Sleeveless Sweater', 30),
(121, 'Dry Clean', 'Boy', 'Sweater', 40),
(122, 'Dry Clean', 'Boy', 'Tie', 20),
(123, 'Dry Clean', 'Boy', 'Kurta', 40),
(124, 'Dry Clean', 'Boy', 'Pyjama', 40),
(125, 'Dry Clean', 'Boy', 'Kurta-Pyjama', 80),
(126, 'Steam Press', 'Boy', 'T-Shirt', 10),
(127, 'Steam Press', 'Boy', 'Shirt', 10),
(128, 'Steam Press', 'Boy', 'Lower', 10),
(129, 'Steam Press', 'Boy', 'Trouser', 10),
(130, 'Steam Press', 'Boy', 'School Blazer', 30),
(131, 'Steam Press', 'Boy', 'Blazer', 30),
(132, 'Steam Press', 'Boy', 'Suit(2pc)', 40),
(133, 'Steam Press', 'Boy', 'Suit(3pc)', 50),
(134, 'Steam Press', 'Boy', 'Jacket', 30),
(135, 'Steam Press', 'Boy', 'Sweat Shirts', 10),
(136, 'Steam Press', 'Boy', 'Pullover', 10),
(137, 'Steam Press', 'Boy', 'Sleeveless Sweater', 10),
(138, 'Steam Press', 'Boy', 'Sweater', 10),
(139, 'Steam Press', 'Boy', 'Tie', 10),
(140, 'Steam Press', 'Boy', 'Kurta', 10),
(141, 'Steam Press', 'Boy', 'Pyjama', 10),
(142, 'Steam Press', 'Boy', 'Kurta-Pyjama', 20),
(143, 'Dry Clean', 'Girl', 'Top', 30),
(144, 'Dry Clean', 'Girl', 'Jeans', 40),
(145, 'Dry Clean', 'Girl', 'Shirt', 40),
(146, 'Dry Clean', 'Girl', 'Skirt', 40),
(147, 'Dry Clean', 'Girl', 'Trouser', 40),
(148, 'Dry Clean', 'Girl', 'Shorts', 40),
(149, 'Dry Clean', 'Girl', 'Suit(2pc)', 50),
(150, 'Dry Clean', 'Girl', 'Suit(3pc)', 70),
(151, 'Dry Clean', 'Girl', 'Kurta', 30),
(152, 'Dry Clean', 'Girl', 'Anarkali Kurta', 50),
(153, 'Dry Clean', 'Girl', 'Salwar', 20),
(154, 'Dry Clean', 'Girl', 'Sleeveless Sweater', 30),
(155, 'Dry Clean', 'Girl', 'Sweater', 40),
(156, 'Dry Clean', 'Girl', 'Lehenga(2pc)', 100),
(157, 'Dry Clean', 'Girl', 'Lehenga', 50),
(158, 'Dry Clean', 'Girl', 'Choli', 20),
(159, 'Dry Clean', 'Girl', 'Dupatta', 20),
(160, 'Dry Clean', 'Girl', 'Dress', 50),
(161, 'Dry Clean', 'Girl', 'Frock', 40),
(162, 'Steam Press', 'Girl', 'Top', 10),
(163, 'Steam Press', 'Girl', 'Jeans', 10),
(164, 'Steam Press', 'Girl', 'Shirt', 10),
(165, 'Steam Press', 'Girl', 'Skirt', 20),
(166, 'Steam Press', 'Girl', 'Trouser', 10),
(167, 'Steam Press', 'Girl', 'Shorts', 10),
(168, 'Steam Press', 'Girl', 'Suit(2pc)', 30),
(169, 'Steam Press', 'Girl', 'Suit(3pc)', 40),
(170, 'Steam Press', 'Girl', 'Kurta', 10),
(171, 'Steam Press', 'Girl', 'Anarkali Kurta', 20),
(172, 'Steam Press', 'Girl', 'Salwar', 10),
(173, 'Steam Press', 'Girl', 'Sleeveless Sweater', 10),
(174, 'Steam Press', 'Girl', 'Sweater', 10),
(175, 'Steam Press', 'Girl', 'Lehenga(2pc)', 50),
(176, 'Steam Press', 'Girl', 'Lehenga', 30),
(177, 'Steam Press', 'Girl', 'Choli', 10),
(178, 'Steam Press', 'Girl', 'Dupatta', 10),
(179, 'Steam Press', 'Girl', 'Dress', 30),
(180, 'Steam Press', 'Girl', 'Frock', 20),
(181, 'Dry Clean', 'Others', 'Purse Ladies', 70),
(182, 'Dry Clean', 'Others', 'School Bag', 80),
(183, 'Dry Clean', 'Others', 'Travelling Bag', 100),
(184, 'Dry Clean', 'Others', 'Soft Toys', 50),
(185, 'Dry Clean', 'Others', 'Teddy Small', 50),
(186, 'Dry Clean', 'Others', 'Teddy Big', 100),
(187, 'Laundry', 'Household', 'Hand Towel', 10),
(188, 'Laundry', 'Household', 'Bath Towel', 20),
(189, 'Laundry', 'Men', 'Hand Trouser', 20),
(190, 'Laundry', 'Men', 'Shirt', 20),
(191, 'Laundry', 'Men', 'T-Shirt', 20),
(192, 'Laundry', 'Men', 'Jeans', 20),
(193, 'Laundry', 'Women', 'Night Gown', 30),
(194, 'Laundry', 'Household', 'Single Bed Sheet', 40),
(195, 'Laundry', 'Household', 'Double Bed Sheet', 60),
(196, 'Laundry', 'Household', 'Pillow Cover', 10),
(197, 'Laundry', 'Women', 'Top', 20),
(198, 'Laundry', 'Women', 'Jeans', 20),
(199, 'Laundry', 'Women', 'Shorts', 20),
(200, 'Laundry', 'Women', 'Shirt', 20),
(201, 'Laundry', 'Women', 'Saree', 5),
(202, 'Laundry', 'Women', 'Blouse', 20),
(203, 'Laundry', 'Women', 'Kurta', 20),
(204, 'Laundry', 'Women', 'Pyjama', 20),
(205, 'Laundry', 'Women', 'Dupatta', 20),
(206, 'Laundry', 'Women', 'Lower', 20),
(207, 'Laundry', 'Men', 'Lower', 20),
(208, 'Dry Clean', 'Household', 'Single Bed sheet', 40),
(209, 'Dry Clean', 'Household', 'Double Bed Sheet', 60),
(210, 'Dry Clean', 'Household', 'Pillow Cover', 20),
(211, 'Dry Clean', 'Household', 'Sofa Cover per Seat', 40),
(212, 'Dry Clean', 'Household', 'Dining Table Cover', 50),
(213, 'Dry Clean', 'Household', 'Small Paidaan', 50),
(214, 'Dry Clean', 'Household', 'Big Paidaan', 100),
(215, 'Dry Clean', 'Household', 'Blanket Single Bed', 150),
(216, 'Dry Clean', 'Household', 'Blanket Double Bed', 200),
(217, 'Dry Clean', 'Household', 'Quilt single Bed', 200),
(218, 'Dry Clean', 'Household', 'Quilt Double Bed', 250),
(219, 'Dry Clean', 'Household', 'AC Quilt Single Bed', 80),
(220, 'Dry Clean', 'Household', 'AC Quilt Double Bed', 100),
(221, 'Dry Clean', 'Household', 'Curtains', 80),
(222, 'Dry Clean', 'Household', 'Fills Normal', 40),
(223, 'Dry Clean', 'Household', 'Fills Heavy', 60),
(224, 'Dry Clean', 'Household', 'Carpet', 13),
(225, 'Steam Press', 'Household', 'Curtains', 40),
(226, 'Steam Press', 'Household', 'Fills Normal', 20),
(227, 'Steam Press', 'Household', 'Fills Heavy', 40);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `login_id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`login_id`, `username`, `password`, `name`) VALUES
(1, 'door2door', 'd2d@123', 'Sumit Mishra');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
