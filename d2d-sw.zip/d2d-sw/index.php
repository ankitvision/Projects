<!DOCTYPE html>
<html>
<head>
<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href="http://fonts.googleapis.com/css?family=Orbitron" rel="stylesheet" 
        type="text/css"/>
<meta charset="UTF-8">

<title>Billing Software</title>
<script type="text/javascript">
function digiClock() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('t').innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(digiClock, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}	
</script>
<style>
body {
    background: url('pics/d2d2.jpg') no-repeat fixed center center;
    background-size: cover;
    font-family: Montserrat;
}


.login-block {
    width: 320px;
    padding: 20px;
    background: #fff;
    border-radius: 5px;
    border-top: 5px solid #ff656c;
    margin: 0 auto;
}

.login-block h1 {
    text-align: center;
    color: #000;
    font-size: 18px;
    text-transform: uppercase;
    margin-top: 0;
    margin-bottom: 20px;
}

.login-block input {
    width: 100%;
    height: 42px;
    box-sizing: border-box;
    border-radius: 5px;
    border: 1px solid #ccc;
    margin-bottom: 20px;
    font-size: 14px;
    font-family: Montserrat;
    padding: 0 20px 0 50px;
    outline: none;
}

.login-block input#username {
    background: #fff url('http://i.imgur.com/u0XmBmv.png') 20px top no-repeat;
    background-size: 16px 80px;
}

.login-block input#username:focus {
    background: #fff url('http://i.imgur.com/u0XmBmv.png') 20px bottom no-repeat;
    background-size: 16px 80px;
}

.login-block input#password {
    background: #fff url('http://i.imgur.com/Qf83FTt.png') 20px top no-repeat;
    background-size: 16px 80px;
}

.login-block input#password:focus {
    background: #fff url('http://i.imgur.com/Qf83FTt.png') 20px bottom no-repeat;
    background-size: 16px 80px;
}

.login-block input:active, .login-block input:focus {
    border: 1px solid #ff656c;
}

.login-block button {
    width: 100%;
    height: 40px;
    background: #ff656c;
    box-sizing: border-box;
    border-radius: 5px;
    border: 1px solid #e15960;
    color: #fff;
    font-weight: bold;
    text-transform: uppercase;
    font-size: 14px;
    font-family: Montserrat;
    outline: none;
    cursor: pointer;
}

.login-block button:hover {
    background: #ff7b81;
}
.tabBlock
        {
            background-color:#57574f;
            border:solid 0px #FFA54F;
            border-radius:5px; -moz-border-radius:5px; -webkit-border-radius:5px;
            max-width:200px;
            width:100%;
            overflow:hidden;
            display:block;
        }
		#t, #d{
			
			font-size:25px;
		}
	
    
</style>
</head>

<body onload="digiClock()">
<br/><br/>
<div id="datetimeblock">
	<?php
		 date_default_timezone_set("Asia/Kolkata");
	?>
	<label id="t"></label></br>
	<label id="d"><?php echo date('D, d-m-Y');?></label>
</div>
<br/><br/><br/><br/><br/>

<div class="login-block">
    <h1>Login</h1>
	<form method="post" action="">
    <input type="hidden" value="Sumit Mishra" name="nme" id="nme" />
    <input type="text" value="" placeholder="Username" name="username" id="username" />
    <input type="password" value="" placeholder="Password" name="password" id="password" />
    <input type="submit" name="sub" value="Login"/>
	</form>
</div>

</body>

</html>
<?php
if(isset($_POST['sub'])){
include 'config.php';
session_start();
$name=$_POST['nme'];
$username=$_POST['username'];
$password=$_POST['password'];

$q="SELECT * FROM login where username='$username' and password='$password'";

$res=mysqli_query($con,$q);
//print_r($res); die('lost');
 $flag=mysqli_num_rows($res);
if($flag==1) {
	header('location:welcome.php');
	} else {
	echo 'Wrong Username and Password';
	}
}

?>
